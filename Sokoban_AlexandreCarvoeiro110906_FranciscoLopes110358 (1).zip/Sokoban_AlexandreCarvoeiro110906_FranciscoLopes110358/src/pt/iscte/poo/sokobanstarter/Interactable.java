package pt.iscte.poo.sokobanstarter;

import java.util.List;

public interface Interactable {

	void interactWithEmpilhadora(Empilhadora empilhadora, List<GameElement> gameElements);

}
