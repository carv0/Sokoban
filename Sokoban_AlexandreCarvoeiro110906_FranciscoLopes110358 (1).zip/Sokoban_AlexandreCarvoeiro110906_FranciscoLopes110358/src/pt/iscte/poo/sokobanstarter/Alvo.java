package pt.iscte.poo.sokobanstarter;

import pt.iscte.poo.utils.Point2D;

public class Alvo extends Chao {

	public Alvo(Point2D Point2D, String imageName) {
		super(Point2D, imageName);
	}

}
